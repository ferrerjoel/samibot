# samibot

A multipurpose bot. Needs node_modules of discord_js in order to work. Made for learning purposes.

Requires:

@discordjs/voice
@discordjs/opus

Optional:

ffmpeg-static

# Main features

-The bot can change all users nicknames for absolutely no reason at all!

-Can ping pong

-Rick roll your voice chat

-Change all disconected user alias for the lyrics of the famous 1978 song! (beta)

-Create random generated teams of the people you are in VC with!
